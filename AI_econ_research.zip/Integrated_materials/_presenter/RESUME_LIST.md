# Live sessions: what to open, and where

**Presenter's crib sheet. Not for students.** Session titles name projects and collaborators.
Build the public zip with `zsh tools/make_public_zip.sh`, which leaves this folder out and then
checks that it did.

One row per live moment in `slides/AI_econ_research.pdf`. Page numbers are the final 73-page deck.

## How resuming works, and its three limits

`claude --resume "<term>"` opens the picker filtered by the term, so you never type a session id in
front of a room. The term has to match the session's **current title** --- so `/rename` the session
to the name in the table once, before the talk, and it stays.

1. **There is no search inside a resumed session.** Scroll your terminal for your own phrases ---
   that is what the "scroll to" column is for. Note the turn, not only the id.
2. **Sessions above about 15 MB reopen slowly.** For those, a screenshot beats a live open.
3. **A decision made in a picker leaves no trace**, so anything you chose through a menu will not be
   in the scrollback. Say it aloud instead of looking for it.

If the venue's network is doubtful, every row below can be a screenshot taken beforehand.

---

## Parts b and d

| p | Slide | Open | Resume term / command | Scroll to | What to say |
|---|---|---|---|---|---|
| 18 | My daily routine, live | **fresh** | `zsh live/setup_demo.sh`, then `claude -n "[temp] demo"` in `~/demo_ai_talk` | — | the order of the opening commands; the two things set up once (an MCP for Stata/MATLAB, and deny rules) |
| 22 | A session is a notebook on your disk | **fresh**, second terminal | `ls -lh ~/.claude/projects/` then `wc -l <newest>.jsonl` | — | the file *is* the session; the folder name comes from where you started |
| 23 | Live — one small task, written well | resume | `claude --resume "` ______________________ `"` | the opening brief, read clause by clause | what it settles in advance, what it forbids, what it defers |
| 25 | Live — managing context inside one session | resume | `claude --resume "` ______________________ `"` | where the window fills, and the handoff that closed it | what went to a file instead of into the chat |
| 27 | Live — across sessions: the project folder | **not a session** | open a `ProjectManagement/` folder in the terminal or an editor | the handoffs in date order, then `plans/` | a folder is the only thing that survives a session |
| 56 | Part d: Live — the outputs | **not a session** | open the run folder | one unit's evidence files, its two tables and the droplog; then the console with three sessions running | the format is what makes it checkable |

*Two blanks to fill: the session behind the small-task demo, and the one you open for the
context demo.*

---

## Part f — the nine steps

Part f is your real project, scrubbed hard on the slides. They name the **method** — Nash-in-Nash,
bargaining power — and nothing else: no field, no institution, no outcome, no data source.
**So the slides are safe and the sessions are not.** When you open one live you are showing more than
the slide does — keep the last column in view.

Rename each session once to the term in the middle column and the resume line on the day is one
short thing to type. Full session ids, alternates, and the complete list of your own messages per
session are in `ProjectManagement/two_projects_reference/resume_list_teacher.md` in the repo —
**not in this package**.

| p | Step | Resume term | Scroll to | Keep off screen |
|---|---|---|---|---|
| 67 | 1. Join a project someone else started | `teacher: the coauthor's data and folder structure` | `I don't need to read every line of the code, remember that` · `now write a prompt to do test 2 to 3` | the memo's test statistics; the coauthor's name and quoted messages; folder paths |
| 67 | 2. Does bargaining power bind, and what would kill the project | `teacher: institutions and the first tests` | `are these suggested by the news or the papers you mentioned` · `if there is no variation explained by it, we don` | **43 MB, reopens slowly — screenshots are better here** |
| 67 | 3. Run the tests, take the null, change the question | `teacher: read the posted-wage paper and test it` | `reading the original` · `mark that they are your thoughts, not my thoughts` · `But I don't want to stop here` | the paper's identity; the results themselves |
| 68 | 4. Build the measure, check it by hand | `teacher: election panel rebuild` | `do I need to eyeball anything for your results` · `break it down and I will do it` · `I have checked 10 random rows` | the register's name; unit names |
| 68 | 5. Link two registers, with the agent and an RA | `teacher: crosswalk with the RA` | `crosswalk_checkpoint.md. do this.` · `so then we do gain huge if we do the full search` · `let's call it a pause here for now` | the RA's name; the review table's contents |
| 68 | 6. Extend the link, do not trust coverage | `teacher: union finance extract` | `before I lay out the plan` · `be more creative in creating tests to make me believe` · `a handoff for the next session` | **the `where is ...` turn names places — screenshot only, or skip** |
| 69 | 7. Anatomize the two papers, pitch the idea | `teacher: reading guide and the pitch` | `these are the latest results` · `I am not that buying your argument` · `clean up this audio transcript` | both papers' identities; the colleagues' names |
| 69 | 8. Take the critique, rebuild the missing primitive | `teacher: derived demand for teachers` | `strong functional form` · `don't eliminate E from the welfare` · `note to myself` | the model as written — show the *moves*, not the specification |
| 69 | 9. Pin the protocol, write the game, simulate | `teacher: formal model and simulation` | `now wait for my instruction` · `They choose district instead of schools` | the propositions; the simulation's numbers |

**Steps 10–13 have no session.** They have not happened in this project; the slide says so. If you
want something real on screen there, the honest substitute is a test file or a Monte Carlo table from
the other structural project.

---

## After the talk

Fill this in while it is fresh --- what you actually opened, and what you wished you had opened
instead. That is the column no reconstruction can recover.

| Slide | What I actually opened | Worked / did not |
|---|---|---|
|  |  |  |
