> Redacted copy for the public package (04_console_runner_cn.md). Firm names, the two capacity
> directories, the business-registry databases and all local paths are replaced
> by placeholders. Everything else is as it actually ran.

# 主会话编排 prompt (console_runner_v1) — block 执行器

> 在 Claude Code（DeepSeek gateway）的一个 session 里粘贴本 prompt 启动。一个 session 负责一个或多个 block；session 之间靠 block 清单互斥，绝不重叠。

## 你的任务

按顺序处理**使用者指定的 firm 清单文件**（每行一个 uid；如 `config/sessions/session_03.txt`），对每家企业跑 **采集 → 校验 → 抽取 → 校验 → 报告** 流水线。你是**编排器**：自己不做任何搜索或判断，只派发 subagent、跑校验脚本、写 RUN_LOG。**进度写到使用者指定的独立日志**（如 `sessions/RUN_LOG_s03.md`）——每会话一个日志，避免 10 会话争抢同一文件。

工作目录：`<PROJECT_ROOT>/`（下称 ROOT；启动时由使用者告知绝对路径）。

## 每家企业的流水线

1. **读锚点** `anchors/<uid>.json`；从 `config/search_list_v1.csv` 取该 uid 行。
2. **机械填充采集 prompt**：读 `prompts/program_collect_v3.md`，把 `{{uid}}`、`{{canonical_cn}}`、`{{aliases_cn}}`（|连接）、`{{names_en}}`、`{{credit_codes}}`、`{{anchor_json}}`（锚点 JSON 原文）替换进去。**除槽位替换外不得改动模板一个字。**（`sessions/filled/collect_<uid>.md` 已是填好的现成版，可直接读取派发，省去填充。）
3. **派采集 subagent**（Task 工具，独立 context）：prompt=填充后的全文。等待返回。
4. **校验**：`python3 validation/validate_program.py <uid> --stage collect`。FAIL → 把错误清单附在原 prompt 末尾（"上一轮校验错误，请修复后重写输出文件：…"）重派**一次**；再 FAIL → RUN_LOG 记 `collect_FAIL`，跳过该企业后续步骤。
5. **派抽取 subagent**：同法填充 `prompts/program_extract_v4.md`（**现行版 v4＝严格锚点口径**；槽位：uid/canonical_cn/aliases_cn/credit_codes；或直接读 `sessions/filled/extract_<uid>.md`——但须确认该文件为 v4）。
6. **校验**：`validate_program.py <uid> --stage extract`。FAIL → 同上重派一次。
7. **派报告 subagent**：填充 `prompts/program_report_v1.md`。
8. **校验**：`validate_program.py <uid> --stage report`。
9. **RUN_LOG**：向**本会话专属**日志（如 `sessions/RUN_LOG_s03.md`）追加一行（见格式）。

## 并发

同时最多 **5 家**企业在流水线中（即最多 5 个在途 subagent；一家的 collect 返回后即可派它的 extract，无需等其他家）。不要为省事把多家合进一个 subagent——**一家企业一个独立 context** 是本设计的硬约束。

## RUN_LOG 格式（真相源；只追加，不改史）

```
| 时间 | block | uid | 企业 | 阶段结果 c/e/r | E数 | 项目数 | 事件数 | firm_status | 校验 | 备注 |
```
块开始/结束各写一行横幅（block 号、起止时间、**引擎＝DeepSeek V4 Pro**、prompt 版本号）。任何异常（subagent 超时、文件缺失、重派）都记备注。

## Block 收尾

一个 block 全部结束后：
1. 跑 `python3 validation/validate_program.py --block <K>`（整块复核）。
2. 在 RUN_LOG 写块小结：`block K: n家 | found_programs=… | no_program=… | excluded=… | FAIL=… | 总E=… | 总项目=… | 总事件=…`。
3. 停下等使用者指令（继续下一 block / 结束 session）。

## 纪律

- 模板文件、firm 清单、校验脚本均为只读；产出只写 evidence/ extract/ reports/ namecheck/ sessions/ 五处。
- 不得跳过校验步骤；不得手工"修补" subagent 的输出文件（要改就重派）。
- 使用者中断后重启：先读 RUN_LOG 判断该 block 已完成到哪家，从下一家继续（幂等）。
