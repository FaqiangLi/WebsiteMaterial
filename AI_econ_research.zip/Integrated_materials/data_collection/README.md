# Collecting data at scale, with two models

This is the whole prompt chain behind Part d of the talk: an operation that went out and found
firm-level investment events — which firm built what capacity, where, and when — for about
1,400 firms, at a granularity no database sells. Ten parallel sessions, three at a time, Claude and
DeepSeek doing two different jobs, a machine gate between the two stages, and RAs checking behind
it. About $350--420 for the full run.

**Everything here is redacted.** Firm names, the two industry capacity directories, the
business-registry databases and all local paths are replaced by `[bracketed placeholders]`.
Nothing else is changed: the prompts are as they ran, version numbers and all.

---

## Start here: do not read this folder

**It will look intimidating, and most of it is not for you.** These files document one large
operation in obsessive detail — controlled vocabularies, credibility tiers, stop rules, a validator
that rejects its own output. That detail exists because *this* job needed it. Yours almost certainly
needs less, and a different subset.

**So do not read it. Have an agent read it, and then have it interview you.** Put this folder where
your agent can see it and paste the following.

```text
Read every file in [path to this data_collection folder] before you answer anything. They are the
prompts, the tutorial, the checklist and the contingency table from a large AI-assisted data
collection run by an economist. Treat them as accumulated experience — the method, the failure modes
and the checks — not as a template to copy. Most of the specifics will not apply to me.

Then interview me before you propose anything. Ask the questions whose answers would change what you
build. At a minimum:

- what unit I am collecting on, and roughly how many of them there are
- what exactly I need per unit, and what I already have
- which sources exist, in which language, and which sit behind a login or a paywall
- which cases I already know the answer to, so they can be used as tests
- what my budget is, in money and in hours, and what a failed run costs me
- what "done" looks like, and who checks it

One round of questions, then stop and wait for my answers.

Once I have answered, give me four things:

1. A plan in my own terms, saying explicitly which parts of that folder's method apply to my problem
   and which are overkill for it and should be dropped. I want the second list to be long.
2. The pitfalls in those files that my problem is actually exposed to — and the ones it is not.
3. A first prompt for my job, in the eight-block shape from the skeleton, filled in with my
   specifics rather than theirs.
4. A pilot: a handful of units chosen to break it, including at least one case whose answer I
   already know, and the checks that must pass before I spend real money.

Do not write the production prompt until the pilot has run and I have read its output.
```

**What that gets you.** The experience in this folder, cut down to your problem, in an hour instead
of a weekend. The nitty-gritty stays in the files; only the part that applies reaches you.

**Two things to insist on, whatever it proposes.** Keep collection and judgement in separate stages,
and seed the pilot with cases whose answers you already know. Everything else here is negotiable;
those two are what the operation was built on.

---

## The shape, before the files

The one design decision everything else follows from: **cut the job in two.**

```
   Stage A  COLLECT          gate         Stage B  EXTRACT        Stage C  REPORT
   zero judgment        ──────────▶     all the judgment     ──▶   a human view
   goes to the web       a validator     never goes to the
   one unit per          script, not     web, reads only
   fresh context         a model         Stage A's files
```

Two reasons, and the second is the one people miss:

- **Replicability.** All judgment sits in one stage. It can be audited, re-run and changed without
  going back to the web — and what was collected survives every change of mind about how to read
  it.
- **No contamination.** A worker that is judging while it searches will search for what it has
  decided to find.

**Who does what.** DeepSeek does the bulk zero-judgment collection, where the Chinese-language
sources are, one independent context per firm, in parallel. Claude runs the pipeline, the
extraction stage and the gate. The RAs check every hit for source authenticity and faithful
extraction, and blind-sample a quarter of the misses. **Code** does the deterministic aggregation
and deduplication — never let a model merge records by feel.

---

## The files, in the order you would use them

| File | What it is |
|---|---|
| `13_prompt_skeleton_cn.md` | **Start here.** The eight-block skeleton every collection prompt is built from: the job and its hard edges · identity and anchors · the evidence block · sources ranked · stop rules · evidence discipline · running it · delivery |
| `11_checklist_cn.pdf` | The one-page checklist to run before spending money on a batch |
| `12_contingency_table_cn.pdf` | What to do when a tool is blocked, a site refuses, a run stalls --- the failure modes and their fixes |
| `10_tutorial_cn.pdf` | The 16-page tutorial: the whole method written out, with the pilot evidence behind each rule |
| `01_collect_prompt_cn.md` | **Stage A**, the production collection prompt, as it ran |
| `02_extract_prompt_cn.md` | **Stage B**, the production extraction prompt: two tables and a droplog |
| `03_report_prompt_cn.md` | **Stage C**, the per-firm report prompt |
| `04_console_runner_cn.md` | The orchestrator: what you paste into the session that dispatches the others |
| `05_prompt_changelog_cn.md` | **The most useful file here.** Every version bump, and the pilot evidence that forced it |

The Chinese-language documents are `_cn`; the prompts are in Chinese because the sources are.

---

## How to run it on your own problem

1. **Freeze the frame and give it a version number.** Mine went 1,588 → 1,373 units once duplicates
   and out-of-scope firms were removed. A frame that moves during a run is not a sample.
2. **Separate what you already have from what you are going out to find.** Anything you supply is
   an **anchor**: it confirms identity and cross-checks, and it never counts as a finding. Both
   production prompts say this three times, because it was the failure that cost the most.
3. **Pilot on a handful chosen to break it** — not a random sample. Cover the extremes. Seed it
   with cases whose answer you already know, mixed in so the worker cannot tell them apart.
4. **Run the three pre-flight checks** (`12_contingency_table_cn.pdf`): can it reach the network,
   can it run code and write to disk, can it get text out of a PDF — each proved *in the
   environment the run will use*.
5. **Write the quality standard as code.** A rule in prose is a suggestion; the same rule in a
   validator is a gate. Put the *substantive* rule in the gate, not just the structure — the one
   bug that got through this run was well-formed in every structural way.
6. **One independent context per unit.** Concurrency capped. Progress in a run log so a restart
   resumes instead of repeating.
7. **Write to disk early and often**, so an interrupted run is not a zero.

## The two things that went wrong

**A version bump that did not reach the runner.** The prompt went from v3 to v4; the file that
actually executes the job still named v3. Nothing failed loudly. When you bump a version, **grep
every file that names the old one** — especially the one the executor reads.

**A supplied file came back as findings.** Handing the workers capacity figures I already owned, so
they could confirm the right firm, made the output about twice as rich as the pilot — and most of
the extra content was that same file returned to me. Anything you supply is an anchor, marked as
supplied, never counted as evidence. Otherwise your robustness check is polluted by design: you are
comparing the outside source against a copy of itself.

## What the placeholders mean

`[产能库A]` and `[产能库B]` are two commercial capacity directories; `[工商信息库]` is a business
registry; `[企业A]`…`[企业K]` are real firms in the pilot, each kept consistent across files so the
changelog still reads; `[某市]`, `[某园区]` are places; `<PROJECT_ROOT>` is wherever you put the
run folder. Internal unit ids like `P0506` are our own and are left as they are.
