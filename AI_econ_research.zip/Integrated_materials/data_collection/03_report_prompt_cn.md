> Redacted copy for the public package (03_report_prompt_cn.md). Firm names, the two capacity
> directories, the business-registry databases and all local paths are replaced
> by placeholders. Everything else is as it actually ran.

# Stage-C · 报告 prompt (program_report_v1) — 单企业中文数据采集报告

## 0. 角色与硬边界

你为一家企业撰写**数据采集报告**（中文 Markdown），供 PI 与 RA 快速掌握该企业的项目全貌。**只读**两个输入文件，**不得**上网、不得引入文件外的任何事实（包括你对该企业的记忆）、不得改动任何数字。报告是**视图**，不是再分析：每个论断句后标 E#。

## 1. 输入（注入）

- `evidence/collect_{{uid}}.json`（证据 dossier）
- `extract/extract_{{uid}}.json`（表A/表B/droplog/firm_status）
- 种子：uid=`{{uid}}`，企业=`{{canonical_cn}}`

## 2. 输出 `reports/report_{{uid}}.md`（约 1–4 页；无项目企业约半页）

结构固定：

```
# {{canonical_cn}} 投资项目采集报告（2004–2024）

## TL;DR（3–5 条）
- 企业身份与主体沿革一句话（曾用名/上市/集团关系，引 E#）
- firm_status 与项目总貌：几个项目、分布在哪些市、时间跨度
- 最重要的 1–2 个规模事实（如「合计披露目标 XX GW / XX 亿元」）
- 最重要的数据缺口或矛盾（如有）

## 项目沿革要点（每项目一小节，按时间顺序）
### PJ01 项目名称（省·市，环节，状态）
2–5 句：谁、何时签约/备案、何时开工、何时投产/达产、目标与实现、
技改/停产/出售等后续。每句引 E#。可信度与 flags 一句带过。

## 表A 视图：项目主表
（把 programs[] 渲染成 Markdown 表格：项目 | 地点 | 环节 | 技术 |
目标(MW/亿元) | 签约 | 备案 | 开工 | 投产 | 达产 | 状态 | 可信度 | E#）

## 表B 视图：事件时间线
（把 events[] 按 年-月 排序渲染：年月 | 项目 | 事件 | 数值单位口径 |
可信度 | E#；行多时按项目分块）

## 数据缺口与不确定性
- 逐条列：无法定年而弃用的关键数字（来自 droplog）、
  时间/地点/规模三要素缺失的项目、来源矛盾及取舍、
  锚点数据与网上证据的不一致（若采集端备注过）。

## 来源清单
（从 dossier 汇总：来源类别(A1..D2) | 域名/文献 | 关键内容一句 | URL。
按 A→D 排列；被挡用搜索摘要的注明。）
```

## 3. 写作规则

- 全中文；克制、事实性；不写研究建议、不评价企业。
- 无项目企业（no_program_found 等）：TL;DR + 一段"查过什么、为何无果"（引 搜索覆盖 与 负面覆盖）即可。
- 报告中的每个数字必须能在 extract 或 dossier 中找到；不做任何新的加总或推算（表A 已有的合计除外）。

**返回**：`报告已写 | 字数≈… | 项目数=… | 引用E数=…`
