# AI Toolbox for Empirical Research — course materials

**Version 1.0 · September 2026** · Faqiang Li, Peking University
`faqiangli.econ@gmail.com` · **https://www.faqiangli.com/teaching**

**What this is.** A two-hour workshop on using an AI coding agent — Claude Code — for empirical
economics research, originally given at Renmin University and Peking University. This
folder is everything from it: the slides, the handout, every prompt I showed, and the full prompt chain
from the large data-collection operation in Part d.

**You do not need to have been there.** The slides are written to be read on their own. A handful of
pages are markers for live demos given from a terminal — each one says so, in grey. Everything those
demos showed is described somewhere in the slides or in `prompts/`.

The version above is the one to quote; the website carries the current one, and it is updated
routinely.

**Licence.** Share and adapt with credit, not for commercial use, under the same terms
(CC BY-NC-SA 4.0). Please don't sell these for money; do feel free to share them with your friends.

---

## What is in here

```
slides/            the talk, 73 pages
handout/           context engineering tips — 6 pages, read this one on paper
prompts/           every prompt from the slides, one file each, ready to fill in
  examples/          whole task briefs from live projects, taken apart block by block
data_collection/   the full Claude + DeepSeek collection operation, and how to run it
```

## Where to start, depending on why you are here

**You came out of the talk and want to try something tomorrow.**
`prompts/00_one_liners.md`, then `prompts/08_n_ledger.md`. The first four lines cost you nothing
and change what you get back. The N-ledger is the one that catches real bugs.

**You want the argument, not the tricks.**
`handout/context_engineering_tips.pdf`, six pages. Section 1 is three facts the rest sits on; they
will still be true when every command in here has been renamed.

**You are about to start a project with an agent in it.**
`prompts/examples/` first — a real task brief from a live project, annotated block by block. Then
`prompts/12_closing_a_session.md`, which is the habit everything else depends on.

**You have a collection job that no database will do for you.**
`data_collection/README.md` — and read only the first section, which is a prompt that hands the
reading to an agent and has it interview you instead. The folder is a complete working system, not an
illustration, and most of it will be overkill for your problem.

## How to use the prompts

Every prompt file has the same shape: **when to use it**, the prompt itself, **what it did for
me**, and **the transferable part**. Square brackets are slots — `[path to the draft]`,
`[your field]` — so replace them and the prompt works as it stands.

The prompts in `prompts/` are cleaned up: grammar fixed, specifics replaced by blanks, ready to
paste. **The slides quote what I actually typed, typos and all** — that is deliberate, because real
prompts are messier than advice about prompts, and pretending otherwise would be the one dishonest
thing in this package. Where a file here and the slide differ, use the file and believe the slide.

## Three things worth knowing before you copy anything

1. **Most of this is not an AI skill.** Deciding what the task actually is, what it rests on, and
   how you would know it worked — that is research ability. The agent only makes the cost of
   being vague visible sooner.
2. **These are field notes, not a curriculum.** Many will go out of date as the tools improve. The
   context window will not.
3. **The prices are mine.** I was on a $200-a-month plan and used most of it. Scale it to what you
   are comfortable paying; almost every habit here works on a smaller plan, just with fewer
   parallel workers and shorter unattended runs.

## Credit

The talk draws on Paul Goldsmith-Pinkham's *Getting Started with Claude Code* (Substack post and
video series), and on Gentzkow and Shapiro's *Code and Data for the Social Sciences: A
Practitioner's Guide* — research-management foundations that matter more, not less, in an AI
world. Two figures in the slides are reproduced from a third-party article and are credited on the
page.

Suggestions and corrections are welcome: `faqiangli.econ@gmail.com`.
