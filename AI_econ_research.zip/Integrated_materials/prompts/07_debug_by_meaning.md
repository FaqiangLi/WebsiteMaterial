# Debug by meaning, not by syntax

*Slide: Part c, "Debug by meaning, not by syntax".*

**When to use it.** A result looks wrong. Do *not* open the code and start reading line by line
--- the cheapest debug is in plain English.

```text
Walk through the calculation step by step on three example rows and tell me what you find.
```

**What it did for me.** It turns a code-reading problem into a reading problem.

**How to read the answer** — this is the whole method:

- Compare its walk-through against your own intuition about the data.
- **If they disagree, you have a target** for a code-level look.
- **If they agree, the problem is upstream** — in the data, not the code.

**The transferable part.** This only works if you have your own feel for the data. That is what
all the eyeballing is for.
