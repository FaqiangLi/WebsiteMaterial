# A context-less audit, anchored on the script that actually runs

*Slide: Part c, "A context-less audit, anchored on the script that actually runs".*

**When to use it.** When you want an independent review of code you and the agent have been
working on for weeks — from a reviewer that has not absorbed the working session's assumptions.

```text
I want the audit to be **context-less** --- not conditional on any prior knowledge. Your request
to each parallel sub-agent should be only: explain what the scripts do, explain the theory, and
that is it.

Line 1 of the brief must name **[the entry script you actually run]** --- that is the live one.

Then: state the theory, and check the internal consistency of the [estimation and simulation]
algorithms against all the related scripts.

Run this **twice, with two different framings**, and keep the two reports separate.
```

**What it did for me.** Two audits with different framings, kept as separate reports so their
disagreement stayed visible.

**The three rules it left me with:**

1. **Line 1 of every audit brief names the live entry script** — the one you actually run. An
   audit not anchored on it will happily review dead code; both of mine had cited lines that were
   commented out.
2. **A finding that cannot quote a live line is void.**
3. **Two audits with different framings, never one.**
