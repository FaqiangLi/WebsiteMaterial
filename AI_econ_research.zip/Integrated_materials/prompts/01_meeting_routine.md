# The meeting routine: from a recording to the next instruction

*Slide: Part c, "The meeting routine — from a recording to the next instruction".*

**When to use it.** After any meeting you recorded and had transcribed. The transcript will be
full of mis-heard words, especially technical ones; your own notes are what repairs them.

**Attach**: the transcript, and your own notes from the meeting.

```text
Summarise and group the discussion into sections, with the to-do items for each section, and
end with a chronological sweep of what the meeting went through.

The transcript is error-ridden, so when you work out what a wrong word should have been, lean
on the notes I am supplying: [attach or name your own notes]. But the summary note itself must
be based on the meeting only.

Leave out irrelevant chit-chat.

[Optional, and worth adding: I disagree with [the point someone made] --- weigh it rather than
simply recording it as settled.]
```

**What it did for me.** A sectioned note with to-do items, which I then read, correct in place,
date, and paste into the working session as its next instruction.

**The transferable part.** Your notes are the *context* that repairs the transcript's wrong
words; the summary itself must come *only* from the meeting. Keep those two jobs separate in
the prompt, or the model will quietly write your notes into the minutes.

Paste your own doubt in alongside the note, so the agent weighs a coauthor's proposal instead
of obeying it. And if you use GitHub issues, they are the better carrier for the to-do items;
this is how to do it without them.
