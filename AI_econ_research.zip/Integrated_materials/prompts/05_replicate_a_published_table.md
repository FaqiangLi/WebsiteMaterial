# Before you trust a new dataset, replicate a published table

*Slide: Part c, "Before you trust a new dataset, replicate a published table".*

**When to use it.** The moment a new extract exists and before a single result rests on it.

```text
I am an economist but I have limited knowledge of [the institutional area this data comes from].
I have put a paper at [path to the paper] in the folder. Read [the section that uses this data,
and the table number], try to replicate the numbers from my extract. If they come out very
close, good --- then interpret the numbers for me concretely, with examples.
```

**What it did for me.** The mismatches exposed **five real bugs** in a newly built extract from
seventeen years of a very large administrative dataset — including an import/export flag that
was reversed.

**The transferable part.** Someone has already published a number from almost any dataset you are
about to use. Reproduce it first. And note the shape of the ask: not *"check my data"* but
*"reproduce this specific published number"* — a target it can fail against.

The last clause matters too. Asking it to interpret the number concretely is how you find out
whether the match was real or a coincidence of scaling.
