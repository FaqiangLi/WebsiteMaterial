# The fortnightly review

*Slide: Part e, "The fortnightly prompt".*

**When to use it.** Every week or two, for half an hour. Find out what is actually open on your
laptop, and close most of it.

```text
I want to use this session to clean up my sessions in Claude Code. Give me the list of sessions
with their titles, a brief description of each, the date created and the date last active. For
the description, read the first and last few sections of each session file.
```

**What it did for me.** A table of every session I have. Close the finished ones, delete the
one-liners, keep the two or three that still hold real work.

**The transferable part.** **Archive before you delete** — unnamed is not empty. When I pruned
67 untagged sessions, four of them turned out to have real work in them.

It is also the fastest way to find a session you only half remember.

And while you are at it: read `git log` instead of scrolling chat history.
