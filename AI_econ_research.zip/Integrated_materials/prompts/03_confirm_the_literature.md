# Confirm what the literature actually says

*Slide: Part c, "Confirming what the literature actually says".*

**When to use it.** Every single time an agent drafts text with citations in it, before that text
goes to a coauthor, a referee, or a student.

```text
Double-check your references: for each one, does the claim actually appear in that paper, and
on what page? [The note is at: [path to the draft].]
```

**What it did for me.** Problems in **all six** references: an invented verbatim quotation,
swapped editors, wrong journal details, a wrong paper, and a false claim about a real one.

**The transferable part.** Make it standard, not occasional:

- Require **the paper and the page** for every claim — *"cite the page where this is stated"*.
- Then **open one or two at random and read them yourself**.

Asking whether a paper exists is not the same as asking whether it says what you were told.
