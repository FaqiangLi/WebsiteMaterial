# Four one-liners to steal first

*Slide: Part c, "One-liners — steal these first".*

No setup, no context, nothing to fill in. The phrasing is the whole thing.

---

### 1. Slow it down when the work needs care

```text
Take your time. I know you are fast. I need quality and verification.
```

**When.** Anything where being wrong is expensive: an estimation change, a merge, a number
that will go in a table.

---

### 2. Parallelise

```text
Use sub-agents to parallelise.
```

**When.** Whenever you were about to have it read three things in a row — and whenever you
catch yourself browsing inside your working session. A sub-agent has its own fresh context
window, so the browsing does not eat yours.

**This is the most counter-intuitive one**, and the one people adopt last.

---

### 3. Make it interview you

```text
Before you implement anything, interview me: ask the questions whose answers would change
what you build. One round, then wait.
```

**When.** At the start of any task big enough that you cannot write the perfect brief — which
is every task. Cheaper than trying to write a perfect prompt, which is not possible anyway.

---

### 4. Ignore its adjectives

Not a prompt so much as a reading habit. *"The cleanest version yet"*, *"a great catch"* ---
praise is not evidence. When it admires its own output:

```text
Argue the other side. What is wrong with what you just did?
```

and read that instead.
