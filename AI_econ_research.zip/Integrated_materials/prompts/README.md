# The prompts

Every prompt shown in the talk, one file each, in the order they appear on the slides.

**These are cleaned-up versions.** The deck quotes what I actually typed, typos and all — that
is part of the point. What you get here is the same prompt with the grammar fixed and the specifics
replaced by `[bracketed slots]`, so you can paste it straight into a session and fill in the blanks.
Where a file here and the slide differ, use the file and believe the slide.

## Index

| File | Slide | Use it when | What it does |
|---|---|---|---|
| `00_one_liners.md` | Part c | Any session, any time | Four lines that change what you get back: slow it down, parallelise, make it interview you, ignore its adjectives |
| `01_meeting_routine.md` | Part c | You recorded a meeting | Turns an error-ridden transcript into a sectioned note with to-do items, repaired against your own notes |
| `02_literature_feed_skill.md` | Part c | Once, then weekly | Builds a **skill** that collects new papers in your field and files the ones you pick |
| `03_confirm_the_literature.md` | Part c | Before any cited text leaves your hands | Checks that each paper says what it was cited as saying. Found problems in all six of mine |
| `04_reference_manager.md` | Part c | The unfiled pile got away from you | Files hundreds of papers into your existing structure, reversibly |
| `05_replicate_a_published_table.md` | Part c | A new extract exists | Reproduces a published number from it before anything rests on it. Found five real bugs |
| `06_be_honest.md` | Part c | After a run whose answer you were hoping for | Makes it hunt for where your expectations leaked into its own prompts |
| `07_debug_by_meaning.md` | Part c | A result looks wrong | Debugs in English before you open the code, and tells you whether the bug is in the code or upstream |
| `08_n_ledger.md` | Part c | Every data brief, always | Every merge and filter prints rows in, out and dropped. An unexplained change in N is a bug |
| `09_context_less_audit.md` | Part c | Code you have lived with for weeks | An independent audit from a reviewer that never saw your assumptions |
| `10_fortnightly_review.md` | Part e | Every week or two | Lists every session you have so you can close most of them |
| `11_deep_look_back.md` | Part e | Every few months | Reads all your sessions back and tells you how you actually work |
| `12_closing_a_session.md` | Part b | Before closing any session that did real work | The three things to leave behind, and what a handoff must contain |

`examples/` holds whole task briefs from live projects, annotated block by block — the material
behind *"why the prompt is the work"*. `../data_collection/` holds the full prompt chain from the
large collection operation in Part d.

## Two conventions

**Square brackets are slots.** `[path to the draft]`, `[your field]`, `[the entry script you
actually run]`. Replace them; nothing else needs changing.

**Nothing here needs a special tool.** These are plain messages. They work in Claude Code, and
most of them work in any chat window — the ones that do not are the ones that ask the agent to
read your files or spawn sub-agents, which is exactly the difference the talk is about.
