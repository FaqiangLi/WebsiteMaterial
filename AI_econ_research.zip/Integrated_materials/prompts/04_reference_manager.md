# Put your reference manager in order

*Slide: Part c, "Putting your reference manager in order".*

**When to use it.** When the unfiled pile in [Zotero / your reference manager] has grown past the
point where you will ever sort it by hand.

**Use plan mode**, and attach a screenshot of your existing folder tree.

```text
You are going to work on my [Zotero] library. File the unsorted papers into folders following
the structure in my left-hand column [Image #1]. **Do not move papers that are already grouped.**

Before you change anything: back up the database, and tag every change you make so the whole
thing can be undone in bulk.
```

**What it did for me.** Unfiled papers fell from about 300 to a few dozen in one session. It
backed the database up first and tagged every change, so the whole thing was reversible.

**The transferable part.** Before any bulk change to a library you care about:

1. **Back up.**
2. **Tag every change** so it is reversible.
3. **Test the rule of thumb you are about to trust.** Mine — *"the bigger file is the one with
   my notes"* — turned out to be right less than half the time.
