# A weekly literature feed you pick from — built as a skill

*Slide: Part c, "A weekly literature feed you pick from".*

**When to use it.** Once, in plan mode, to build the thing. After that it is one command a week.

**Ask for a skill, not a favour.** The point is in the framing: you are not asking it to do this
for you this week, you are asking it to *build you a skill that does this* — packaged
instructions it loads on one command. Say the word in the prompt.

```text
I want you to build me a **skill** that runs a weekly literature feed. Plan it first, then we
will build it.

**Input.** A weekly sweep of [NBER working papers + the top five journals + RAND + AEJ: Applied
+ IER + REStud --- replace with the sources your field actually reads].

**Output, and how I will use it.**
1. Every week I want to read a feed of the new [empirical IO] papers --- [no theory papers] ---
   each with its abstract and a one-sentence brief, grouped by topic and delivered to me as
   [a page I can open / a file].
2. After scanning, I will pick some to download and read properly.
3. The downloaded ones should be wired into [Zotero / your reference manager] and filed in the
   right collection. The ones I only skimmed must **not** be added.
4. If I change any of these steps later, what we build should adapt easily.
5. Anything else you think is worth adding.

Think it through and come back with a plan.
```

**What it did for me.** A feed page every week that I skim and tick, instead of newsletters I do
not read; the picked papers land in the right collection. It turned into a reading partner too
--- point it at what it just collected, ask it to rank them, ask what each one would change.

**The transferable part.** Notice how much of that prompt is about *how the output will be used*
rather than what to fetch. Step 3's "the skimmed papers should not be added" is one clause, and
it is the clause that keeps the library clean.
