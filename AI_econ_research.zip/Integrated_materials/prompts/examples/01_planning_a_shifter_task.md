# Example 1: opening a session to build a new variable

*A real task brief, sent at the start of a session. Every specific — paths, dataset names, data
vendors, product codes, variable names — has been replaced by a `[bracketed slot]`; the
structure, the order of the blocks and the phrasing are unchanged. The parenthetical labels are
the author's own annotations, added afterwards to mark what each block is doing.*

*Slide: Part b, "Live — one small task, written well".*

---

**(what this prompt is for)**

```text
This prompt is designed to prepare for constructing a shifter for an exploratory analysis.
```

**(point it at the standing instructions first)**

```text
Read `[path to the task's leading .md]` and learn the background and motivation for this task,
and what we are doing in this session. To do it, the implementation details you need for
building the [new variable] are below. For the other tasks mentioned in the `.md`, just follow
the `.md`.
```

**(data category — what we have been using, and what we will use here)**

```text
In previous sessions, summarised in `[path to the earlier handoff]`, we used [data source A] and
[data source B] to build [the earlier objects]. That should help you understand the main
[capacity] data we are working with.

We now have a different set of exercises, introduced in the leading `.md` above --- our empirical
model has had a big overhaul since that handoff. We will use the same datasets for this exercise:

1. `[working/<file 1>.dta]` --- [unit]-[period], [what it holds].
2. `[working/<file 2>.dta]` --- [unit]-[period], [what it holds].
3. `[working/<file 3>.dta]` --- [unit]-[period], with [the dummies and columns that matter].
```

**(motivation — say what the variable is *for*, not just what it is)**

```text
The core goal is to build shifters that can hopefully explain investment differences across
firms. There is a slight difference between how investment events are defined in the earlier
exercise and in our empirical model, but let us set that subtlety aside for now. All we need in
this session is to see what explains most of the heterogeneity in [investment sizes] across
[the units].
```

**(steps to finish the task)**

```text
From reading the leading instruction `.md` you will know that you first need to compile
[the aggregate series] from `[the dataset]` into a [period]-by-[destination] level figure. That
part is easy --- you will find it in the working folder: `[file]`, [N] [markets] nested in [M]
regions × [period], [units]. That gives you [the demand quantity] and the [destination-to-region
map] for the shifters.
```

**(steps to finish the task, and predict the problems in advance)**

```text
Then comes the harder part. You will need the crosswalked [trade] data --- read the instructions
and find the dataset you need at `[path to the crosswalk HOWTO]`. Firms in our original list that
do **not** appear in the crosswalk are treated as impossible to match to any entity in a given
year, so they are non-exporters.

The [trade] data come in two parts: the standard one at `[path]`, and [a second, richer vintage].
For the second, refer to `[the earlier cleaning script]`, written before I heavily fixed the
crosswalk --- so it is only useful for learning **how to handle that vintage**; everything else
you need is in the `.md` above. It is essentially the same data, just with more fields. They may
be useful later, but for now collapse them to the same shape as the standard one.

And by the way: the raw standard files are nasty to clean, so you may need some time to peel them
apart **without exploding the storage from the zip**. On that front I recommend starting a
parallel sub-agent. In the end we only need the `[product code]` exports for our target firms ---
[and note the code changes before [year], when it also blends in other products] --- which is a
manageable file size.
```

**(the actual ask — one sentence, near the end)**

```text
That should be all you need. Once you have built it, [run it against firm investment size], and
break the investigation down by [source A] and [source B].
```

**(what to hand back)**

```text
When you explore the dataset and write the final report, share [the intermediate shares] with me,
and write very clearly in the final deliverable what you used for every implementation detail.
```

**(output path)**

```text
Deliverables go in `[path to the documentation folder]`; output [the LaTeX report] into the
output folder.
```

**(constrain the output format)**

```text
All code succinct --- no need to write a lot --- commented so that I can take it over myself, in
[do-files] unless efficiency demands otherwise. Store it in `[codes/<subfolder>]`.
```

**(name what you are *not* doing yet)**

```text
I mentioned in the leading `.md` that we will also try [a second shifter] in the same exercise.
We can talk about that later, after we have sufficiently finished this one.
```

**(hand over)**

```text
Now go and make the plan.
```

---

## What to take from it

- **The ask is one sentence.** Everything above it is context: where the files are, what was
  already decided, what has changed since, what is out of scope.
- **Problems are predicted, not discovered.** The storage warning and the sub-agent suggestion are
  one sentence each and both come from having been burned before.
- **Two things are deliberately deferred** — the second shifter, and the definitional subtlety
  about investment events. Saying "not now" is as load-bearing as saying "do this".
- **The output contract is explicit**: which folder, which format, how much code, commented for
  handover.
- **It ends in plan mode.** *"Now go and make the plan"* — nothing is built until you have read
  the plan back.
