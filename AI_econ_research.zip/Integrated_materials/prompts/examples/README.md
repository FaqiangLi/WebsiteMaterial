# Worked examples: real prompts, taken apart

The files in `../` are single-purpose prompts you can lift and use. These are different: they are
**whole task briefs from live projects**, annotated block by block, so you can see what a long
prompt is actually made of and in what order.

This is the material behind Part b of the talk — the live page *"one small task, written well"*, and
the slide after it, *"why the prompt is the work"*.

## How to read one

Each file keeps the author's own parenthetical labels — `(motivation)`, `(data category)`,
`(steps to finish the task, predict potential problems)`, `(output path)` and so on. Those labels
are not part of the prompt; they were added afterwards to mark what each block is doing. Read the
labels first, then the block.

Every concrete specific — paths, file names, data vendors, variables, product codes — is
replaced by a `[bracketed slot]`. Fill the slots with your own and the brief works as it stands.

## What to notice

1. **How much of it is context rather than instruction.** The actual ask is usually one or two
   sentences near the end. Everything before it is the agent being told where things are, what has
   already been decided, and what not to redo.
2. **Problems predicted in advance.** *"the raw data are nasty to clean, you might need time to
   peel it off without exploding the storage"* — a sentence that costs nothing to write and
   saves an hour.
3. **What is deliberately deferred.** *"we can talk about this later, after we sufficiently finish
   the first part"* — naming the thing you are *not* doing is part of the brief.
4. **The output contract at the end.** Where deliverables go, in what format, and how terse the
   code should be.

## Adding your own

Drop a `NN_short_name.md` in here with the same shape: a one-line description at the top, then the
brief with `(labels)` above each block and `[slots]` in place of specifics. Nothing else needs to
change — there is no index to update.
