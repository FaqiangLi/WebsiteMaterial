# The deep look-back: have it read six months of your own sessions

*Slide: Part e, "The deep look-back — point it at six months of your own sessions".*

**When to use it.** Every few months.

**What it actually is.** Every session you have ever run is a file on your disk, under
`~/.claude/projects/`. Six months of mine is about 275 files and 12 GB — a record of how I work that
I did not write and cannot argue with.

**It is a project, not a question.** One session whose only job is to dispatch; parallel sub-agents,
a slice of the files each, so the reading never fills the window it is being reported into; one
report assembled at the end.

```text
Read every session file in ~/.claude/projects/ from the last [six months]. Use parallel sub-agents,
one slice of the files each, so the reading does not fill your own window.

Report four things, in this order:
  1. what I did right;
  2. what I did wrong — and what it cost me;
  3. what I made more complicated than it needed to be;
  4. what I should change.

Group by theme, not by session. Keep it concise and use plain language. Quote me where the
quotation is the evidence, and where a claim is about a habit, say in how many sessions it shows up.

Do not give me lessons anyone would learn in their first hour with the tool.
```

**The four-way split is the whole trick**, and *"and what it cost me"* is the clause doing the work.
Without it you get a list of minor sins with no weight. My first attempt had no equivalent and came
back with a page of generalities.

**What came back for me.** 159 sessions read, a 48-page report, 56 lessons. Three that changed what
I do:

- **no git commits at all** in six months;
- almost every session started from my home folder, so **my project rules never loaded**;
- over a thousand standing permissions and **no deny rules**.

I would have denied all three if you had simply asked me.

**The transferable part.** A self-review is only as good as its brief. Ask a vague question about
your own habits and you will get a flattering summary; the four-way split, the cost clause, and the
instruction not to state the obvious are what make it specific enough to hurt.

**Its smaller sibling** is `10_fortnightly_review.md` — same idea, half an hour, every week or two.
