# "Be honest: were the results bent toward what I expected?"

*Slide: Part c, "Be honest: were the results bent toward what I expected?"*

**When to use it.** After any unattended run whose result you were hoping for — especially one
that checks a number you produced some other way. The agent knew what you expected; it read your
earlier messages.

```text
Be honest: was there any deliberation or selection in these results? I want the [search /
collection / estimation] process to be independent and trustworthy, and you should not have been
influenced by [my earlier rough estimates / the number I said I was expecting].

Go back through your own prompts and tell me where my expectations leaked in.
```

**What it did for me.** It searched its own prompts, found two places where my expectations had
leaked in, and re-ran the numbers without them. The main result held — which is the only reason
I can cite it.

**The transferable part.** Ask for the test, not for reassurance. *"Are you sure?"* gets you
reassurance; *"go and find where I contaminated this"* gets you a test.

And the cleanest version of this check is a **sub-agent with no memory of what you were hoping
for** — it cannot be influenced by a conversation it never saw. See `09_context_less_audit.md`
for the same idea applied to code.
