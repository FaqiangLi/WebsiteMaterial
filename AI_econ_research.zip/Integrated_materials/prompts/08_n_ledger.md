# The N-ledger: every merge and filter prints its counts, and you read them

*Slide: Part c, "The N-ledger — every merge and filter prints its counts, and you read them".*

**When to use it.** Always, in every data brief. The agent writes and runs the cleaning code, so
you never see the merge table yourself — and every merge, filter and drop quietly redefines
your estimating sample.

**The rule that goes into every data brief:**

```text
After every merge and every filter, print rows in, rows out, and rows dropped. An unexplained
change in N is a bug until it is explained.
```

**And the question to ask afterwards:**

```text
Show me how you get to this number of observations from each of your data selection steps.
```

**What it did for me.** Twice, at least:

- An "active" filter was doing nothing — over half the rows had zero capacity. Fixing it voided
  a night of estimation runs and **flipped a key sign**.
- One line of a summary — *91 rows had no match* — led to a case-sensitive merge that had
  silently dropped a firm from every regression of two sessions.

**The transferable part.** No regression output would have shown either. The ledger is thirty
lines you can read without reading any code.
