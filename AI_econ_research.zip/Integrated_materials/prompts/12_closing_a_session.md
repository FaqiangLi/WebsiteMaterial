# Closing a session: the leave-behind

*Slide: Part b, "Across sessions — the whole rationale".*

**When to use it.** Before you close any session that did real work — written at a task
boundary, never at the end of your patience. Start a new session by the time the window is 80%
full; by the time it breaks it cannot even write its own handoff.

```text
Before we close, write three things:

1. A summary of what was done.
2. A paste-ready starter prompt for the next session.
3. One educative note for this project's `KNOWLEDGE.md`.
```

**Without all three, the next session pays the same context tax twice.**

**What a handoff must contain** to be worth writing:

- frozen facts — the numbers and decisions that are settled
- real file paths
- what is still open
- **what not to redo**
- a checkable bar for "done"

**One thing people miss.** A decision made in a picker leaves no trace. Anything you chose through
a menu or an approval prompt is invisible to the next session — restate it in plain text.

**The transferable part.** Four triggers for starting a new session rather than continuing:

1. A small task is finished — the next task is the next session.
2. You are about to branch a risky version.
3. You want to run two similar things side by side.
4. You want to pilot something small, then scale.
